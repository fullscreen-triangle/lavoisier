### Proteomics Workflow


- io (read input file)
- filters (filter data by quality and features)
- process - incoorperate experimental design
- normalization 
- annotations - adding metadata
- analysis - e.g column correlations
- plots 